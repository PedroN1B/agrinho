let sementes = [];

function setup() {
  createCanvas(800, 600);
  background(135, 206, 235); // céu azul claro
}

function draw() {
  drawBackground();
  
  // Crescer sementes
  for (let semente of sementes) {
    semente.crescer();
    semente.mostrar();
  }
}

function mousePressed() {
  if (mouseY > height / 2) { // só planta no "chão"
    sementes.push(new Semente(mouseX, mouseY));
  }
}

function drawBackground() {
  noStroke();
  fill(135, 206, 235); // céu
  rect(0, 0, width, height / 2);

  fill(34, 139, 34); // grama
  rect(0, height / 2, width, height / 2);
}

class Semente {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.altura = 5;
    this.maxAltura = 50;
  }

  crescer() {
    if (this.altura < this.maxAltura) {
      this.altura += 0.1;
    }
  }

  mostrar() {
    stroke(0);
    fill(0, 100, 0);
    line(this.x, this.y, this.x, this.y - this.altura);
    ellipse(this.x, this.y - this.altura, 10, 10); // folhinha
  }
}
